package org.cucumber.pageobjects;

import org.cucumber.runner.TestRunner;
import org.openqa.selenium.By;

public class LoginPageOHRMPO extends TestRunner {

	public By usernameTextLocator = By.name("username");
	public By passwordTextLocator = By.name("password");
	public By loginBtn = By.xpath("//button[@type='submit']");
	
}
