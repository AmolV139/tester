package org.cucumber.pageactions;

import org.cucumber.pageobjects.LoginPageOHRMPO;

public class LoginPageOHRMPA extends LoginPageOHRMPO {

	public void enterDataInusernameTextLocator(String data)
	{
		getDriver().findElement(usernameTextLocator).sendKeys(data);
	}
	
	public void enterDataInpasswordTextLocator(String data)
	{
		getDriver().findElement(passwordTextLocator).sendKeys(data);
	}
	
	public void clickLoginBtn()
	{
		getDriver().findElement(loginBtn).click();
	}
	
	
}