package org.cucumber.runner;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider; 
import org.testng.annotations.Test;

import io.cucumber.testng.FeatureWrapper;
import io.cucumber.testng.PickleWrapper;

@io.cucumber.testng.CucumberOptions(features = "src/test/resources/FeatureFilesFolder", glue = {
		"org.cucumber.stepdefs" }, plugin = { "pretty", "json:target/cucumber-reports/Cucumber.json",
				"junit:target/cucumber-reports/Cucumber.xml",
				"html:target/cucumber-reports/spark.html" }, monochrome = true)

public class TestRunner {
	public static WebDriver driver;
	private io.cucumber.testng.TestNGCucumberRunner testRunner;

	@BeforeClass
	public void setUP() {
		ChromeOptions opt = new ChromeOptions();
		opt.addArguments("start-maximized");
		driver = new ChromeDriver(opt);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		testRunner = new io.cucumber.testng.TestNGCucumberRunner(TestRunner.class);
	}

	public static WebDriver getDriver() {
		return driver;
	}

	public void navigateToURL(String data) {
		driver.navigate().to(data);
	}

	@Test(description = "login", dataProvider = "features")
	public void login(PickleWrapper pickle, FeatureWrapper cucumberFeature) {
		testRunner.runScenario(pickle.getPickle());

	}

	@DataProvider(name = "features")
	public Object[] getFeatures() {
		return testRunner.provideScenarios();
	}

	@AfterClass
	public void tearDown() {
		testRunner.finish();
	}
}
