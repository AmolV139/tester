package org.cucumber.stepdefs;

import org.cucumber.pageactions.LoginPageOHRMPA;

import io.cucumber.java.en.*;


public class LoginOHRMStepDef {
	
	LoginPageOHRMPA lpa = new LoginPageOHRMPA();
	
	@Given("^User launches chrome browser and he navigates to URL \"(.*)\"$")
	public void user_launches_chrome_browser_and_he_navigates_to_URL(String URL)
	{
		lpa.navigateToURL(URL);
	}
	
	@When("^I enter the username data as \"(.*)\"$")
	public void i_enter_the_username_data_as(String username)
	{
		lpa.enterDataInusernameTextLocator(username);
	}
	
	@When("^I enter the password data as \"(.*)\"$")
	public void i_enter_the_password_data_as(String password)
	{
		lpa.enterDataInpasswordTextLocator(password);
	}
	
	@When("^I hit the login Button$")
	public void i_hit_the_login_Button()
	{
		lpa.clickLoginBtn();
	}
	

}
